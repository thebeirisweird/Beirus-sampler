#include <jni.h>
#include <oboe/Oboe.h>
#include <vector>
#include <atomic>
#include <mutex>
#include <memory>

class SamplerEngine : public oboe::AudioStreamDataCallback {
public:
    std::mutex mtx;
    std::shared_ptr<oboe::AudioStream> stream;

    std::vector<float> sampleData;
    std::vector<int> chopPoints;

    std::atomic<float> phase{0.0f};
    std::atomic<float> phaseInc{1.0f};
    std::atomic<float> cutoff{1.0f};
    std::atomic<bool> isPlaying{false};

    float prevOut = 0.0f;

    // Recording features (from your PDF add-on)
    std::vector<float> recordedData;
    std::atomic<bool> isRecording{false};

    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* audioData, int32_t numFrames) override {
        auto* out = static_cast<float*>(audioData);

        for (int i = 0; i < numFrames; ++i) {
            float raw = 0.0f;

            if (isPlaying && !sampleData.empty()) {
                int idx = static_cast<int>(phase.load());
                if (idx >= 0 && idx < static_cast<int>(sampleData.size())) {
                    raw = sampleData[idx];
                }
                phase = phase + phaseInc;
                if (phase >= static_cast<float>(sampleData.size())) {
                    isPlaying = false;
                }
            }

            // 1-pole low pass filter
            float c = cutoff.load();
            if (c < 0.0f) c = 0.0f;
            if (c > 1.0f) c = 1.0f;

            float filtered = c * raw + (1.0f - c) * prevOut;
            prevOut = filtered;

            out[i] = filtered;

            if (isRecording) {
                recordedData.push_back(filtered);
            }
        }

        return oboe::DataCallbackResult::Continue;
    }

    bool start() {
        std::lock_guard<std::mutex> lock(mtx);
        if (stream) return true;

        oboe::AudioStreamBuilder builder;
        builder.setDirection(oboe::Direction::Output);
        builder.setSharingMode(oboe::SharingMode::Exclusive);
        builder.setPerformanceMode(oboe::PerformanceMode::LowLatency);
        builder.setChannelCount(1);
        builder.setFormat(oboe::AudioFormat::Float);
        builder.setDataCallback(this);

        oboe::Result r = builder.openStream(stream);
        if (r != oboe::Result::OK || !stream) return false;

        r = stream->requestStart();
        return r == oboe::Result::OK;
    }

    void stop() {
        std::lock_guard<std::mutex> lock(mtx);
        if (stream) {
            stream->requestStop();
            stream->close();
            stream.reset();
        }
    }
};

static SamplerEngine engine;

extern "C" {

JNIEXPORT jboolean JNICALL
Java_com_example_beirus_MainActivity_nativeStartEngine(JNIEnv*, jobject) {
    return engine.start() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeStopEngine(JNIEnv*, jobject) {
    engine.stop();
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeLoadSample(JNIEnv* env, jobject, jfloatArray data) {
    jsize len = env->GetArrayLength(data);
    jfloat* body = env->GetFloatArrayElements(data, nullptr);

    engine.sampleData.assign(body, body + len);
    engine.isPlaying = false;
    engine.phase = 0.0f;

    env->ReleaseFloatArrayElements(data, body, 0);
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeTrigger(JNIEnv*, jobject, jint startFrame) {
    if (engine.sampleData.empty()) return;

    if (startFrame < 0) startFrame = 0;
    if (startFrame >= static_cast<int>(engine.sampleData.size())) startFrame = 0;

    engine.phase = static_cast<float>(startFrame);
    engine.isPlaying = true;
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeAutoChop(JNIEnv*, jobject, jint num) {
    engine.chopPoints.clear();
    if (engine.sampleData.empty() || num <= 0) return;

    int step = static_cast<int>(engine.sampleData.size()) / num;
    if (step <= 0) step = 1;

    for (int i = 0; i < num; i++) {
        engine.chopPoints.push_back(i * step);
    }
}

JNIEXPORT jintArray JNICALL
Java_com_example_beirus_MainActivity_nativeGetChops(JNIEnv* env, jobject) {
    jintArray res = env->NewIntArray(static_cast<jsize>(engine.chopPoints.size()));
    if (!engine.chopPoints.empty()) {
        env->SetIntArrayRegion(res, 0, static_cast<jsize>(engine.chopPoints.size()), engine.chopPoints.data());
    }
    return res;
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeSetPitch(JNIEnv*, jobject, jfloat inc) {
    if (inc < 0.25f) inc = 0.25f;
    if (inc > 4.0f) inc = 4.0f;
    engine.phaseInc = inc;
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeSetCutoff(JNIEnv*, jobject, jfloat c) {
    engine.cutoff = c;
}

JNIEXPORT void JNICALL
Java_com_example_beirus_MainActivity_nativeToggleRecord(JNIEnv*, jobject, jboolean rec) {
    if (rec) engine.recordedData.clear();
    engine.isRecording = (rec == JNI_TRUE);
}

JNIEXPORT jfloatArray JNICALL
Java_com_example_beirus_MainActivity_nativeGetRecordedData(JNIEnv* env, jobject) {
    jfloatArray result = env->NewFloatArray(static_cast<jsize>(engine.recordedData.size()));
    if (!engine.recordedData.empty()) {
        env->SetFloatArrayRegion(result, 0, static_cast<jsize>(engine.recordedData.size()), engine.recordedData.data());
    }
    return result;
}

}
