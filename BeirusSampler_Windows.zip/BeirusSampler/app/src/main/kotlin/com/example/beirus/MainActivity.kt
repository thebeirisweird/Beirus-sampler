package com.example.beirus

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.widget.Button
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    init {
        System.loadLibrary("beirus_engine")
    }

    private lateinit var waveformView: WaveformView

    private var chops = intArrayOf()
    private var samples: FloatArray = floatArrayOf()

    private var isRecording = false

    private external fun nativeStartEngine(): Boolean
    private external fun nativeStopEngine()

    private external fun nativeLoadSample(data: FloatArray)
    private external fun nativeTrigger(frame: Int)
    private external fun nativeAutoChop(num: Int)
    private external fun nativeGetChops(): IntArray

    private external fun nativeSetPitch(inc: Float)
    private external fun nativeSetCutoff(c: Float)

    // Recording features
    private external fun nativeToggleRecord(rec: Boolean)
    private external fun nativeGetRecordedData(): FloatArray

    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) processWav(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        waveformView = findViewById(R.id.waveformView)

        val ok = nativeStartEngine()
        if (!ok) {
            Toast.makeText(this, "Audio engine failed to start (Oboe)", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.btnLoad).setOnClickListener {
            pickFile.launch("audio/*")
        }

        findViewById<Button>(R.id.btnRecord).setOnClickListener {
            handleRecordToggle()
        }

        findViewById<SeekBar>(R.id.pitchSlider).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val inc = (progress.coerceIn(25, 400)) / 100f
                nativeSetPitch(inc)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<SeekBar>(R.id.filterSlider).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val c = progress.coerceIn(0, 100) / 100f
                nativeSetCutoff(c)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    override fun onDestroy() {
        nativeStopEngine()
        super.onDestroy()
    }

    private fun processWav(uri: Uri) {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
        if (bytes == null || bytes.size < 44) {
            toast("Could not read file")
            return
        }

        val decoded = decodeWav16BitPcmToFloatMono(bytes)
        if (decoded == null || decoded.isEmpty()) {
            toast("Only 16-bit PCM WAV is supported right now")
            return
        }

        samples = decoded
        waveformView.updateWaveform(samples)

        nativeLoadSample(samples)
        nativeAutoChop(16)
        chops = nativeGetChops()
        waveformView.updateChops(chops, samples.size)

        toast("Loaded ${samples.size} samples, chopped into ${chops.size}")
    }

    // Minimal WAV parser: RIFF/WAVE, PCM (format=1), 16-bit little-endian
    private fun decodeWav16BitPcmToFloatMono(bytes: ByteArray): FloatArray? {
        fun u32le(off: Int): Int = ByteBuffer.wrap(bytes, off, 4).order(ByteOrder.LITTLE_ENDIAN).int
        fun u16le(off: Int): Int = ByteBuffer.wrap(bytes, off, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF

        if (String(bytes, 0, 4) != "RIFF") return null
        if (String(bytes, 8, 4) != "WAVE") return null

        var offset = 12
        var audioFormat = 0
        var numChannels = 0
        var sampleRate = 44100
        var bitsPerSample = 0
        var dataOffset = -1
        var dataSize = -1

        while (offset + 8 <= bytes.size) {
            val chunkId = String(bytes, offset, 4)
            val chunkSize = u32le(offset + 4)
            val chunkDataOff = offset + 8
            if (chunkDataOff + chunkSize > bytes.size) break

            when (chunkId) {
                "fmt " -> {
                    audioFormat = u16le(chunkDataOff + 0)
                    numChannels = u16le(chunkDataOff + 2)
                    sampleRate = u32le(chunkDataOff + 4)
                    bitsPerSample = u16le(chunkDataOff + 14)
                }
                "data" -> {
                    dataOffset = chunkDataOff
                    dataSize = chunkSize
                    break
                }
            }

            offset = chunkDataOff + chunkSize + (chunkSize % 2)
        }

        if (audioFormat != 1) return null
        if (bitsPerSample != 16) return null
        if (dataOffset < 0 || dataSize <= 0) return null
        if (numChannels !in 1..2) return null

        val frameCount = dataSize / (2 * numChannels)
        val out = FloatArray(frameCount)

        var p = dataOffset
        for (i in 0 until frameCount) {
            var sum = 0
            for (ch in 0 until numChannels) {
                val s = ByteBuffer.wrap(bytes, p, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()
                sum += s
                p += 2
            }
            val mono = sum / numChannels
            out[i] = (mono / 32768f).coerceIn(-1f, 1f)
        }

        toast("WAV ${sampleRate}Hz ${numChannels}ch")
        return out
    }

    private fun handleRecordToggle() {
        isRecording = !isRecording
        nativeToggleRecord(isRecording)

        val btn = findViewById<Button>(R.id.btnRecord)

        if (isRecording) {
            btn.text = "STOP RECORDING"
            toast("Recording...")
        } else {
            btn.text = "START RECORDING"
            val data = nativeGetRecordedData()
            if (data.isEmpty()) {
                toast("No recording captured")
                return
            }
            val file = saveFloatMonoAsWav(data, 44100)
            toast("Saved: ${file?.name ?: "(failed)"}")
        }
    }

    private fun saveFloatMonoAsWav(data: FloatArray, sampleRate: Int): File? {
        // Best-effort file save: app-specific Music folder (no extra permission needed)
        return try {
            val musicDir = if (Build.VERSION.SDK_INT >= 29) {
                getExternalFilesDir(Environment.DIRECTORY_MUSIC)
            } else {
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            }
            val outDir = File(musicDir, "Beirus")
            outDir.mkdirs()

            val file = File(outDir, "Beirus_Beat_${System.currentTimeMillis()}.wav")

            val pcm16 = ShortArray(data.size)
            for (i in data.indices) {
                pcm16[i] = (data[i].coerceIn(-1f, 1f) * 32767f).roundToInt().toShort()
            }

            val baos = ByteArrayOutputStream()
            val byteRate = sampleRate * 2
            val blockAlign: Short = 2
            val subchunk2Size = pcm16.size * 2
            val chunkSize = 36 + subchunk2Size

            fun writeString(s: String) = baos.write(s.toByteArray(Charsets.US_ASCII))
            fun writeLeInt(v: Int) = baos.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array())
            fun writeLeShort(v: Short) = baos.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(v).array())

            writeString("RIFF")
            writeLeInt(chunkSize)
            writeString("WAVE")

            writeString("fmt ")
            writeLeInt(16)
            writeLeShort(1)
            writeLeShort(1)
            writeLeInt(sampleRate)
            writeLeInt(byteRate)
            writeLeShort(blockAlign)
            writeLeShort(16)

            writeString("data")
            writeLeInt(subchunk2Size)

            val bb = ByteBuffer.allocate(subchunk2Size).order(ByteOrder.LITTLE_ENDIAN)
            for (s in pcm16) bb.putShort(s)
            baos.write(bb.array())

            FileOutputStream(file).use { it.write(baos.toByteArray()) }
            file
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val index = when (keyCode) {
            KeyEvent.KEYCODE_Z -> 0
            KeyEvent.KEYCODE_X -> 1
            KeyEvent.KEYCODE_C -> 2
            KeyEvent.KEYCODE_V -> 3
            else -> -1
        }

        if (index != -1 && index < chops.size) {
            nativeTrigger(chops[index])
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
