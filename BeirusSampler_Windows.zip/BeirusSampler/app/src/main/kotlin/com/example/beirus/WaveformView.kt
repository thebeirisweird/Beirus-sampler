package com.example.beirus

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs

class WaveformView(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private var chops = intArrayOf()
    private var totalSamples = 1
    private var samples: FloatArray? = null

    private val waveformPaint = Paint().apply {
        color = Color.parseColor("#888888")
        strokeWidth = 2f
        isAntiAlias = true
    }

    private val markerPaint = Paint().apply {
        color = Color.RED
        strokeWidth = 5f
        isAntiAlias = true
    }

    fun updateWaveform(sampleData: FloatArray?) {
        samples = sampleData
        invalidate()
    }

    fun updateChops(points: IntArray, total: Int) {
        chops = points
        totalSamples = if (total <= 0) 1 else total
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Simple waveform
        val s = samples
        if (s != null && s.isNotEmpty()) {
            val w = width.toFloat()
            val h = height.toFloat()
            val mid = h / 2f

            val step = (s.size / w).toInt().coerceAtLeast(1)
            var x = 0f
            var i = 0
            while (x < w && i < s.size) {
                var peak = 0f
                val end = (i + step).coerceAtMost(s.size)
                for (j in i until end) peak = maxOf(peak, abs(s[j]))
                val y = peak * (h * 0.45f)
                canvas.drawLine(x, mid - y, x, mid + y, waveformPaint)
                x += 1f
                i += step
            }
        }

        // Chop markers
        for (point in chops) {
            val x = (point.toFloat() / totalSamples) * width
            canvas.drawLine(x, 0f, x, height.toFloat(), markerPaint)
        }
    }
}
